logos for the web page
