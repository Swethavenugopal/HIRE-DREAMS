let questions = [
    {
    numb: 1,
    question: "What means ‘language full of technical or special words. ?",
    answer: "Jargon",
    options: [
      "Colloquialism",
"Abbreviations",
"Pedantic words",
"Jargon"
    ]
  },
    {
    numb: 2,
    question: "In any written piece, the sentences of a paragraph should be woven together in such a way that they flow into each other. This principle is called",
    answer: "Order",
    options: [
      "Unity",
"Order",
"Conciseness",
"Coherence"
    ]
  },
    {
    numb: 3,
    question: "A ___ is a systematic series of actions or operations of a series of changes directed to some end.",
    answer: "Process",
    options: [
      "task",
"process",
"activity",
"action"
    ]
  },
    {
    numb: 4,
    question: "Communication is a ___ process in which there is an exchange and chain of ideas towards a mutually acceptable direction.",
    answer: "Two-way",
    options: [
      "One-way",
"Two-way",
"Three-way",
"Four-way"
    ]
  },
    
  // you can uncomment the below codes and make duplicate as more as you want to add question
  // but remember you need to give the numb value serialize like 1,2,3,5,6,7,8,9.....

  //   {
  //   numb: 6,
  //   question: "Your Question is Here",
  //   answer: "Correct answer of the question is here",
  //   options: [
  //     "Option 1",
  //     "option 2",
  //     "option 3",
  //     "option 4"
  //   ]
  // },

];